package com.myconsole.app.commonClass;

import android.util.Log;

public class Utils {
    public static void printLog(String tag, String msg) {
        Log.d(tag, msg);
    }
}
