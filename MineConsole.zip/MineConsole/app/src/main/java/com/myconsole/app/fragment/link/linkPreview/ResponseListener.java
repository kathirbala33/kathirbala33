package com.myconsole.app.fragment.link.linkPreview;

public interface ResponseListener {

    void onData(MetaData metaData);

    void onError(Exception e);
}
